from flask_app import app
from flask import flash, render_template,redirect,session,request
from flask_app.models.user import User
from flask_app.models.adventure import Adventure
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)

@app.route('/dashboard')
def user_dashboard():
    user_data = {
        'id' : session['user_id']
    }
    user = User.get_user_by_id(user_data)
    adventures = Adventure.get_all_adventures_by_user(user_data)
    return render_template('dashboard.html',user=user, all_adventures=adventures)

@app.route('/adventures/new')
def new_adventure_form():
    user_data = {
        'id': session['user_id']
    }
    user = User.get_user_by_id(user_data)
    return render_template('create_adventures.html', user=user)

@app.route('/adventures/create',methods=['POST'])
def create_adventure():
    if not Adventure.validate_create(request.form):
        return redirect('/adventures/new')
    Adventure.create(request.form)
    return redirect('/dashboard')

@app.route('/adventures/<int:id>')
def show_adventure(id):
    user_data = {
        'id' : session['user_id']
    }
    user = User.get_user_by_id(user_data)
    adventures_data = {
        'id': id
    }
    adventure = Adventure.get_one(adventures_data)
    return render_template('show_adventures.html',adventure=adventure,user=user)


@app.route('/adventures/<int:id>/edit')
def show_edit_form(id):
    user_data = {
        'id' : session['user_id']
    }
    user = User.get_user_by_id(user_data)
    adventures_data = {
        'id' : id
    }
    adventure = Adventure.get_one(adventures_data)
    if(adventure.users_id != user.id):
        flash('Unauthorized access to edit recipe with id {id}')
        return redirect('/dashboard')

    return render_template('edit_adventures.html',user=user,adventure=adventure)

@app.route('/adventures/<int:id>/update',methods=['POST'])
def update_adventure(id):
    Adventure.update(request.form)
    return redirect('/dashboard')

@app.route('/adventures/<int:id>/delete')
def delete(id):
    adventures_data = {
        'id' : id
    }
    adventure = Adventure.get_one(adventures_data)
    if(adventure.users_id !=session['user_id']):
        flash('Unauthorized access to edit review with id {id}')
        return redirect('/dashboard')
    Adventure.delete(adventures_data)
    return redirect('/dashboard')

@app.route('/all_adventures')
def show_all():
    user_data = {
        'id' : session['user_id']
    }
    user = User.get_user_by_id(user_data)
    adventures = Adventure.get_all()
    return render_template('show_all.html',user=user, all_adventures=adventures)