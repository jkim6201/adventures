from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
from flask_app.models.user import User
import re

EMAILREGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class Adventure:
    db = "adventures_schema"
    def __init__(self,data):
        self.users_id = data['users_id']
        self.id = data['id']
        self.title = data['title']
        self.place = data['place']
        self.date = data['date']
        self.description = data['description']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.user = None

    @classmethod
    def get_all(cls):
        query = "SELECT * FROM adventures JOIN users ON adventures.users_id = users.id;"
        results = connectToMySQL(cls.db).query_db(query)
        adventures = []
        for row in results:
            adventure = cls(row)
            user_data = {
                'id' : row['users.id'],
                'first_name' : row['first_name'],
                'last_name' : row['last_name'],
                'email' : row['email'],
                'password' : row['password'],
                'created_at' : row['created_at'],
                'updated_at' : row['updated_at'],
            }
            user = User(user_data)
            adventure.user = user
            adventures.append(adventure)
        return adventures

    @classmethod
    def get_one(cls, data):
        query = "SELECT * FROM adventures JOIN users ON adventures.users_id=users.id WHERE adventures.id=%(id)s;"
        results = connectToMySQL(cls.db).query_db(query, data)
        if len(results) < 1:
            return False
        row = results[0]
        adventure = cls(row)
        user_data = {
            'id': row['users.id'],
            'first_name': row['first_name'],
            'last_name': row['last_name'],
            'email': row['email'],
            'password': row['password'],
            'created_at': row['users.created_at'],
            'updated_at': row['users.updated_at']
        }
        user = User(user_data)
        adventure.user = user
        return adventure

    @classmethod
    def create(cls, data):
        query = "INSERT INTO adventures(title,place,date,description,users_id) VALUES(%(title)s,%(place)s,%(date)s,%(description)s,%(user_id)s);"
        return connectToMySQL(cls.db).query_db(query, data)

    @classmethod
    def update(cls, data):
        query = "UPDATE adventures SET title=%(title)s, place=%(place)s, date=%(date)s,description=%(description)s WHERE ID=%(id)s;"
        return connectToMySQL(cls.db).query_db(query, data)
    
    @classmethod
    def delete(cls, data):
        query = "DELETE FROM adventures WHERE id=%(id)s"
        return connectToMySQL(cls.db).query_db(query, data)
    
    @classmethod
    def get_all_adventures_by_user(cls,data):
        query="SELECT * FROM adventures WHERE users_id=%(id)s"
        results = connectToMySQL(cls.db).query_db(query,data)
        adventures = []
        for row in results:
            adventure = cls(row)
            adventures.append(adventure)
        return adventures 
    
    @staticmethod
    def validate_create(adventure):
        is_valid = True
        if len(adventure['title']) < 3:
            flash('Adventure needs to be at least 3 character', 'error')
            is_valid = False
        if len(adventure['place']) < 3:
            flash('Adventure needs to be at least 3 character', 'error')
            is_valid = False
        if 'date' not in adventure:
            flash('Must choose a date', 'error')
            is_valid = False
        if len(adventure['description']) < 3:
            flash('Description needs to be at least 3 character', 'error')
            is_valid = False
        return is_valid
    